# Submission 03

### URL01 (github)
https://github.com/ehabrefaat82/cdond-c3-projectstarter
### URL02 (frontend) 
https://d30qcnsjamg0r7.cloudfront.net/#/employees




## Images Notes
### Screenshot 06
* backend is always inaccessible, the problem is not because of VPC or networking
* I installed apache server enabled port 80, for one of its instances and it works fine.
* unfortunately I am not experienced in node.
* ![](Desktop/cources/Udacity/submission03/cdond-c3-projectstarter/project-submissions/SCREENSHOT06_n.png)


